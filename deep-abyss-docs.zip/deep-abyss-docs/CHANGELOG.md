description: "Add runtime ConfigAuditor to verify Building layer & LayerMask alignment; print one-line GameConfig summary on boot"
globs: ["Assets/DeepAbyssHive/Core/Bootstrap/**"]
alwaysApply: true

# PLAN
- 新增單一腳本 `Assets/DeepAbyssHive/Core/Bootstrap/ConfigAuditor.cs`（命名空間 `DeepAbyssHive.Core.Bootstrap`）。
- 以 `RuntimeInitializeOnLoadMethod` 在進入 Play 後立即執行，不修改場景/Prefab。
- 透過反射嘗試讀取 `Resources/Configs/GameConfig` 的 ScriptableObject（容忍欄位命名差異）。
- 掃描 `Building` layer 是否存在、其 index，並檢查 GameConfig 的 `delete/placement` LayerMask 是否包含/排除該層。
- 以 Smart Console 結構化日誌（分類：`CONFIG`, `PLACEMENT`, `BOOT`）輸出單行摘要，避免刷屏。
- 不移動任何路徑；僅新增此檔。

# CHANGES
WRITE_CHANGE: "Assets/DeepAbyssHive/Core/Bootstrap/ConfigAuditor.cs"
---
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEngine;

namespace DeepAbyssHive.Core.Bootstrap
{
    /// <summary>
    /// Runtime auditor that (1) checks for Building layer presence & LayerMask alignment,
    /// (2) prints a one-line effective GameConfig summary at boot.
    /// No scene changes required; runs once per play.
    /// </summary>
    internal static class ConfigAuditor
    {
        // Try to route logs to Smart Console's DLog(category, message, tags?).
        // If not found, fallback to Debug.Log with the same format to avoid silence.
        private static class Log
        {
            private static readonly MethodInfo dlog2;
            private static readonly MethodInfo dlog3;

            static Log()
            {
                var methods = AppDomain.CurrentDomain.GetAssemblies()
                    .SelectMany(a =>
                    {
                        try { return a.GetTypes(); } catch { return Array.Empty<Type>(); }
                    })
                    .SelectMany(t =>
                    {
                        try { return t.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static); }
                        catch { return Array.Empty<MethodInfo>(); }
                    })
                    .Where(m => m.Name == "DLog")
                    .ToList();

                dlog3 = methods.FirstOrDefault(m =>
                {
                    var ps = m.GetParameters();
                    return ps.Length == 3 &&
                           ps[0].ParameterType == typeof(string) &&
                           ps[1].ParameterType == typeof(string);
                });
                dlog2 = methods.FirstOrDefault(m =>
                {
                    var ps = m.GetParameters();
                    return ps.Length == 2 &&
                           ps[0].ParameterType == typeof(string) &&
                           ps[1].ParameterType == typeof(string);
                });
            }

            public static void D(string category, string message)
            {
                try
                {
                    if (dlog3 != null)
                    {
                        dlog3.Invoke(null, new object[] { category, message, null });
                        return;
                    }
                    if (dlog2 != null)
                    {
                        dlog2.Invoke(null, new object[] { category, message });
                        return;
                    }
                }
                catch { /* fall through */ }

                // Fallback (shouldn't spam; still single-line)
                Debug.Log($"[{category}] {message}");
            }
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        private static void OnAfterSceneLoad()
        {
            // 1) Resolve GameConfig (ScriptableObject) via Resources or Provider, tolerant to naming.
            var cfg = ResolveGameConfig();

            // 2) Building layer check
            int buildingLayer = LayerMask.NameToLayer("Building");
            bool hasBuildingLayer = buildingLayer >= 0;

            // 3) Extract masks (best-effort via reflection)
            int? deleteMask = GetIntMask(cfg, new[] { "deleteLayerMask", "deletionLayerMask", "deleteRayLayerMask", "deleterLayerMask", "deleterMask" });
            int? placementMask = GetIntMask(cfg, new[] { "placementLayerMask", "placerLayerMask", "placeRayLayerMask", "placingLayerMask" });

            // 4) Print CONFIG one-line summary
            var summary = BuildConfigSummary(cfg, deleteMask, placementMask);
            Log.D("CONFIG", summary);

            // 5) Print PLACEMENT alignment result
            if (hasBuildingLayer)
            {
                bool delHasB = deleteMask.HasValue && ((deleteMask.Value & (1 << buildingLayer)) != 0);
                bool placeHasB = placementMask.HasValue && ((placementMask.Value & (1 << buildingLayer)) != 0);
                Log.D("PLACEMENT",
                    $"LayerCheck: BuildingLayer=yes(index={buildingLayer}); deleteMaskHasBuilding={delHasB}; placementMaskHasBuilding={placeHasB} (expected: deleteMask=include, placementMask=exclude).");
            }
            else
            {
                Log.D("PLACEMENT", "LayerCheck: BuildingLayer=NO (請於 Project Settings > Tags and Layers 新增 'Building' 層，確保刪除射線可命中建築物)");
            }
        }

        private static ScriptableObject ResolveGameConfig()
        {
            // Preferred path: Resources/Configs/GameConfig
            // We don't know the exact type; load as generic ScriptableObject.
            ScriptableObject fromResources = Resources.Load<ScriptableObject>("Configs/GameConfig");
            if (fromResources != null) return fromResources;

            // Try any ScriptableObject in Resources/Configs matching name contains "GameConfig"
            var all = Resources.LoadAll<ScriptableObject>("Configs");
            var candidate = all.FirstOrDefault(a => a != null && a.name.IndexOf("GameConfig", StringComparison.OrdinalIgnoreCase) >= 0);
            if (candidate != null) return candidate;

            // Try a provider type with static Instance/Current and property 'Config'
            foreach (var t in AppDomain.CurrentDomain.GetAssemblies().SelectMany(a =>
            {
                try { return a.GetTypes(); } catch { return Array.Empty<Type>(); }
            }))
            {
                if (!t.Name.Contains("GameConfigProvider")) continue;
                var inst = t.GetProperty("Instance", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static)?.GetValue(null)
                           ?? t.GetProperty("Current", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static)?.GetValue(null);
                if (inst == null) continue;
                var cfg = t.GetProperty("Config", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance)?.GetValue(inst) as ScriptableObject;
                if (cfg != null) return cfg;
            }

            return null; // Not fatal; we'll still print available info.
        }

        private static int? GetIntMask(ScriptableObject cfg, IEnumerable<string> names)
        {
            if (cfg == null) return null;
            var t = cfg.GetType();
            foreach (var n in names)
            {
                var f = t.GetField(n, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.IgnoreCase);
                if (f != null)
                {
                    var v = f.GetValue(cfg);
                    if (v is LayerMask lm) return lm.value;
                    if (v is int i) return i;
                }
                var p = t.GetProperty(n, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.IgnoreCase);
                if (p != null && p.CanRead)
                {
                    var v = p.GetValue(cfg);
                    if (v is LayerMask lm2) return lm2.value;
                    if (v is int i2) return i2;
                }
            }
            return null;
        }

        private static string BuildConfigSummary(ScriptableObject cfg, int? delMask, int? placeMask)
        {
            var map = new (string key, string[] aliases)[]
            {
                ("useSpatialIndex", new[] { "useSpatialIndex" }),
                ("requireCreep", new[] { "requireCreep" }),
                ("minSpacing", new[] { "minSpacing" }),
                ("margin", new[] { "margin" }),
                ("snapSize", new[] { "snapSize", "gridSize", "cellSize" }),
                ("rotStep", new[] { "rotStep", "rotationStep" }),
                ("placerToggleKey", new[] { "placerToggleKey", "buildToggleKey" }),
                ("delKey1", new[] { "delKey1", "deleteKeyPrimary" }),
                ("delKey2", new[] { "delKey2", "deleteKeySecondary" }),
                ("spawnKey", new[] { "spawnKey" }),
                ("testKey", new[] { "testKey", "dispatchTestKey" }),
                ("spawnCount", new[] { "spawnCount", "devSpawnCount" }),
                ("rmbLock", new[] { "rmbLock", "rightMouseLock" }),
                ("healthLoggingEnabled", new[] { "healthLoggingEnabled" }),
                ("healthLogInterval", new[] { "healthLogInterval", "healthInterval", "heartbeatInterval" }),
                ("unitBatchSize", new[] { "unitBatchSize" }),
                ("unitBatchInterval", new[] { "unitBatchInterval" }),
                ("verboseLogs", new[] { "verboseLogs" }),
            };

            var parts = new List<string>();
            if (cfg == null)
            {
                parts.Add("GameConfig=NOT_FOUND(Resources/Configs/GameConfig)");
            }
            else
            {
                foreach (var (key, aliases) in map)
                {
                    if (TryGetValue(cfg, aliases, out var val))
                    {
                        // Compact formatting for a few grouped items
                        if (key == "healthLoggingEnabled" || key == "healthLogInterval")
                            continue; // group later
                        parts.Add($"{key}={val}");
                    }
                }

                // Grouped fields
                if (TryGetValue(cfg, new[] { "healthLoggingEnabled" }, out var healthOn) |
                    TryGetValue(cfg, new[] { "healthLogInterval", "healthInterval", "heartbeatInterval" }, out var healthSec))
                {
                    parts.Add($"health={healthOn}@{healthSec}");
                }

                if (TryGetValue(cfg, new[] { "delKey1", "deleteKeyPrimary" }, out var dk1) |
                    TryGetValue(cfg, new[] { "delKey2", "deleteKeySecondary" }, out var dk2))
                {
                    parts.Add($"del={dk1}|{dk2}");
                }

                if (TryGetValue(cfg, new[] { "spawnKey" }, out var sk) &
                    TryGetValue(cfg, new[] { "spawnCount", "devSpawnCount" }, out var sc))
                {
                    parts.Add($"spawn={sk}x{sc}");
                }
            }

            parts.Add($"layers.delete={MaskToNames(delMask)}");
            parts.Add($"layers.placement={MaskToNames(placeMask)}");

            return "GameConfig: " + string.Join("; ", parts);
        }

        private static bool TryGetValue(ScriptableObject cfg, IEnumerable<string> names, out string value)
        {
            value = null;
            if (cfg == null) return false;
            var t = cfg.GetType();
            foreach (var n in names)
            {
                var f = t.GetField(n, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.IgnoreCase);
                if (f != null)
                {
                    var v = f.GetValue(cfg);
                    value = ToStr(v);
                    return true;
                }
                var p = t.GetProperty(n, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.IgnoreCase);
                if (p != null && p.CanRead)
                {
                    var v = p.GetValue(cfg);
                    value = ToStr(v);
                    return true;
                }
            }
            return false;
        }

        private static string MaskToNames(int? mask)
        {
            if (!mask.HasValue) return "(null)";
            var names = new List<string>();
            for (int i = 0; i < 32; i++)
            {
                if ((mask.Value & (1 << i)) != 0)
                {
                    var n = LayerMask.LayerToName(i);
                    names.Add(string.IsNullOrEmpty(n) ? $"#{i}" : n);
                }
            }
            return $"0x{mask.Value:X8}[{string.Join(",", names)}]";
        }

        private static string ToStr(object v)
        {
            if (v == null) return "null";
            switch (v)
            {
                case float f: return f.ToString("0.###");
                case double d: return d.ToString("0.###");
                case bool b: return b ? "True" : "False";
                case Enum e: return e.ToString();
                case LayerMask lm: return $"0x{lm.value:X8}";
                default: return v.ToString();
            }
        }
    }
}
---

# 註解
- 採用 `RuntimeInitializeOnLoadMethod` 以免修改 Boot 流程或 Prefab；最小衝擊。
- 使用反射容忍 GameConfig 欄位命名差異（僅讀、不中斷）；若找不到則打印 NOT_FOUND 提示。
- 日誌分類：`CONFIG`（單行摘要）、`PLACEMENT`（Layer alignment 結果）。
- 刪除 Layer 檢查期望：`deleteMask` 應包含 Building；`placementMask` 通常應排除 Building（避免射線命中已建物）。

# 驗收步驟
- 進入 Play（任意場景）。
- Console 切到 Smart Console，Solo=CONFIG：應看到一行以 `GameConfig:` 開頭的摘要（含 layers.delete/placement 的十六進位與名稱清單）。
- 切到 Solo=PLACEMENT：
  - 若存在 Building layer：應看到 `deleteMaskHasBuilding=True`，`placementMaskHasBuilding=False`（依你們專案慣例）。
  - 若不存在：會看到 `BuildingLayer=NO` 與改善建議。
- 若需要更動 LayerMask，請到 `GameConfig` 物件調整後再 Play，輸出應即時反映。

# 回滾
- 刪除檔案：`Assets/DeepAbyssHive/Core/Bootstrap/ConfigAuditor.cs`。


